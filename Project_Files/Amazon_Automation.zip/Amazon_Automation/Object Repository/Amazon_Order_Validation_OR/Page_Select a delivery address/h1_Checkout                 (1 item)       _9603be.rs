<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Checkout                 (1 item)       _9603be</name>
   <tag></tag>
   <elementGuidId>8adbb1b4-e038-46ab-bd4e-9adc5f6067da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='header']/div/div[3]/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Checkout (1 item)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>649511bc-e7a7-4de4-b28c-7fb9dd625b3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Checkout
        
         (1 item)
        
        
          

  Are you sure you want to return to your Shopping Cart?


  
    
      
        Stay in checkout
      
    
  
  
    
      Return to Cart
    
  


        
      </value>
      <webElementGuid>118ff7c6-5ffe-47c4-b238-e4e635fb10ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header&quot;)/div[@class=&quot;a-row a-grid-vertical-align a-grid-center page-container a-text-center&quot;]/div[@class=&quot;a-column a-span8&quot;]/h1[1]</value>
      <webElementGuid>5be324f7-6eb1-45d1-ba93-82c911b605f6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='header']/div/div[3]/h1</value>
      <webElementGuid>bd380055-7de0-40a7-b885-ccbd0642b1f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Return to Cart'])[1]/following::h1[1]</value>
      <webElementGuid>bd21efe1-03b2-468e-84b0-548748780e39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Are you sure you want to return to your Shopping Cart?'])[1]/following::h1[1]</value>
      <webElementGuid>d4bc7624-993b-4c25-ba6c-fb61d75dafd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Checkout']/parent::*</value>
      <webElementGuid>13a5ae13-b64e-4d32-8b23-04172e147f36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>b35fb6b4-254d-42d7-b3a2-90f61388daa5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = '
        Checkout
        
         (1 item)
        
        
          

  Are you sure you want to return to your Shopping Cart?


  
    
      
        Stay in checkout
      
    
  
  
    
      Return to Cart
    
  


        
      ' or . = '
        Checkout
        
         (1 item)
        
        
          

  Are you sure you want to return to your Shopping Cart?


  
    
      
        Stay in checkout
      
    
  
  
    
      Return to Cart
    
  


        
      ')]</value>
      <webElementGuid>49d2847e-4f5b-471d-b5f4-8aae63954ef5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
