<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Added to Cart</name>
   <tag></tag>
   <elementGuidId>db514b67-b0a4-47ba-82ee-c6d01e749959</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/h1</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.a-size-medium-plus.a-color-base.sw-atc-text.a-text-bold</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Added to Cart&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>e65f2c25-9ab0-4150-9c04-d41e8b3da955</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-medium-plus a-color-base sw-atc-text a-text-bold</value>
      <webElementGuid>2a54385e-43bd-481a-863d-26aba77841cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            Added to Cart
        
    </value>
      <webElementGuid>05da7525-d22a-462e-8898-651b68ca4b52</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;NATC_SMART_WAGON_CONF_MSG_SUCCESS&quot;)/h1[@class=&quot;a-size-medium-plus a-color-base sw-atc-text a-text-bold&quot;]</value>
      <webElementGuid>4c34a72e-50a6-4fcf-8659-c82e4077e64b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/h1</value>
      <webElementGuid>b6a90276-b16a-4992-9348-b1d4e47e6af9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Amazon Basics 2.4 Ghz Wireless Optical Computer Mouse with USB Nano Receiver, Black'])[1]/following::h1[1]</value>
      <webElementGuid>21eecd46-d07a-4d6a-8a37-41ba49389bad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Color:'])[1]/preceding::h1[1]</value>
      <webElementGuid>1a3a1dc3-4706-41ad-85c2-46fcdbbd7c8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Black'])[1]/preceding::h1[1]</value>
      <webElementGuid>a7821930-99d3-491e-a4a4-a2c43a58afd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Added to Cart']/parent::*</value>
      <webElementGuid>13237a9c-e547-4d02-8309-386fea2c0560</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>b1bc3722-9cfa-4de5-a708-b804e3aa6fcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = '
        
            Added to Cart
        
    ' or . = '
        
            Added to Cart
        
    ')]</value>
      <webElementGuid>e95d0c2a-0004-4928-832a-8e048387c785</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
